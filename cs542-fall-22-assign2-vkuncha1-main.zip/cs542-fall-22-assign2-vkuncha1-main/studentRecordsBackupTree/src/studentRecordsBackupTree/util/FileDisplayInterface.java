package studentRecordsBackupTree.util;

import java.util.ArrayList;

public interface FileDisplayInterface {
    public void FileOutputDisplay(ArrayList<Integer> OutputIn,String bstIn);
    public void FileOutputSum(ArrayList<Integer> outputIn, String bstIn);
    public void writeError(String errorIn);

	
}
