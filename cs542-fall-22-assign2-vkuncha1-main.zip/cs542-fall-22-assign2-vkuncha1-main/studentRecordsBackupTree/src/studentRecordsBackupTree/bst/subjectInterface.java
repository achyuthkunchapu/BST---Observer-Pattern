package studentRecordsBackupTree.bst;

public interface subjectInterface {
    public void registerObserver(Node ObjIn);
    public void unregisterObserver(Node ObjIn);
    public void notifyobs();


}
