package studentRecordsBackupTree.bst;

import java.util.ArrayList;

public interface observerInterface {

    public void receiveData();
}
