package studentRecordsBackupTree.bst;

public class PopulateBackups{
    public void populate_backup1(Node ObjIn){
        BST backup_1 = new BST();
        backup_1.insert(ObjIn);
    }
    public void populate_backup2(){
        BST backup_2 = new BST();
    }
}